import pandas as pd
import numpy as np

np.random.seed(42)

# SKUs across FMCG categories
skus = {
    "Detergent_Powder_1kg": {"base": 1200, "seasonality": "summer"},
    "Shampoo_200ml":        {"base": 850,  "seasonality": "flat"},
    "Soap_Bar_100g":        {"base": 2000, "seasonality": "flat"},
    "Instant_Coffee_50g":   {"base": 600,  "seasonality": "winter"},
    "Biscuit_Pack_200g":    {"base": 3000, "seasonality": "flat"},
}

regions = ["North", "South", "East", "West"]
dates = pd.date_range(start="2021-01-01", end="2024-06-30", freq="W")

rows = []
for date in dates:
    for sku, props in skus.items():
        for region in regions:
            base = props["base"]
            # Trend
            trend = 1 + 0.0003 * (date - pd.Timestamp("2021-01-01")).days
            # Seasonality
            month = date.month
            if props["seasonality"] == "summer":
                seasonal = 1 + 0.25 * np.sin((month - 3) * np.pi / 6)
            elif props["seasonality"] == "winter":
                seasonal = 1 + 0.20 * np.cos((month - 1) * np.pi / 6)
            else:
                seasonal = 1.0
            # Festival boost (Oct-Nov)
            festival = 1.15 if month in [10, 11] else 1.0
            # Noise
            noise = np.random.normal(1.0, 0.08)
            # Regional multiplier
            region_mult = {"North": 1.1, "South": 0.95, "East": 0.85, "West": 1.0}[region]
            sales = int(base * trend * seasonal * festival * noise * region_mult)
            sales = max(sales, 0)
            rows.append({
                "date": date.strftime("%Y-%m-%d"),
                "sku": sku,
                "region": region,
                "units_sold": sales,
                "price_inr": round(np.random.normal(
                    {"Detergent_Powder_1kg":95,"Shampoo_200ml":120,"Soap_Bar_100g":45,
                     "Instant_Coffee_50g":180,"Biscuit_Pack_200g":35}[sku], 2), 2),
                "promo_flag": int(np.random.random() < 0.15)
            })

df = pd.DataFrame(rows)
df.to_csv("fmcg_sales_data.csv", index=False)
print(f"Dataset generated: {df.shape[0]} rows")
print(df.head())
