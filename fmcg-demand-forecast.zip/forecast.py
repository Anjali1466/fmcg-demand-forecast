"""
FMCG Demand Forecasting — SKU-Level Stockout Risk Predictor
Author: Pamar (pamarz) | IIT Madras | Chemical Engineering
GitHub: github.com/pamarz

Objective:
  - Forecast weekly FMCG product demand using Prophet
  - Identify SKUs at high stockout risk (demand > reorder point)
  - Output: forecast CSV + stockout risk report

Tools: Python, Prophet, Pandas, Matplotlib
Dataset: fmcg_sales_data.csv (3660 rows, 5 SKUs, 4 regions, 2021–2024)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from prophet import Prophet
import warnings, os

warnings.filterwarnings("ignore")
os.makedirs("outputs", exist_ok=True)

# ── CONFIG ─────────────────────────────────────────────────────────────────────
TARGET_SKU    = "Detergent_Powder_1kg"   # Change to any SKU
TARGET_REGION = "North"                   # Change to any region
FORECAST_WEEKS = 12                       # How many weeks ahead to forecast
SAFETY_STOCK_WEEKS = 2                    # Weeks of safety stock held
LEAD_TIME_WEEKS = 1                       # Supplier lead time

# ── 1. LOAD DATA ───────────────────────────────────────────────────────────────
print("=" * 60)
print("FMCG DEMAND FORECASTING — SKU STOCKOUT RISK PREDICTOR")
print("=" * 60)

df = pd.read_csv("fmcg_sales_data.csv", parse_dates=["date"])
print(f"\n[1] Dataset loaded: {df.shape[0]} rows | {df['sku'].nunique()} SKUs | {df['region'].nunique()} regions")

# ── 2. FILTER & AGGREGATE ──────────────────────────────────────────────────────
df_sku = (
    df[(df["sku"] == TARGET_SKU) & (df["region"] == TARGET_REGION)]
    .groupby("date")["units_sold"]
    .sum()
    .reset_index()
    .rename(columns={"date": "ds", "units_sold": "y"})
)
print(f"[2] Filtered: {TARGET_SKU} | {TARGET_REGION} | {len(df_sku)} weekly records")

# ── 3. TRAIN PROPHET MODEL ─────────────────────────────────────────────────────
print("[3] Training Prophet model...")

# Add Indian festival holidays as regressors
holidays = pd.DataFrame({
    "holiday": ["Diwali"] * 4 + ["Holi"] * 4 + ["Navratri"] * 4,
    "ds": pd.to_datetime([
        "2021-11-04", "2022-10-24", "2023-11-12", "2024-11-01",  # Diwali
        "2021-03-29", "2022-03-18", "2023-03-08", "2024-03-25",  # Holi
        "2021-10-07", "2022-09-26", "2023-10-15", "2024-10-03",  # Navratri
    ]),
    "lower_window": [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
    "upper_window": [ 2,  2,  2,  2,  1,  1,  1,  1,  2,  2,  2,  2],
})

model = Prophet(
    holidays=holidays,
    seasonality_mode="multiplicative",
    weekly_seasonality=True,
    yearly_seasonality=True,
    changepoint_prior_scale=0.05,
    interval_width=0.90,
)
model.add_seasonality(name="monthly", period=30.5, fourier_order=5)
model.fit(df_sku)
print("    Model trained successfully.")

# ── 4. FORECAST ─────────────────────────────────────────────────────────────────
future   = model.make_future_dataframe(periods=FORECAST_WEEKS, freq="W")
forecast = model.predict(future)

forecast_out = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
forecast_out.columns = ["date", "forecast_units", "lower_bound", "upper_bound"]
forecast_out[["forecast_units", "lower_bound", "upper_bound"]] = \
    forecast_out[["forecast_units", "lower_bound", "upper_bound"]].round(0).astype(int)

print(f"[4] Forecast generated for next {FORECAST_WEEKS} weeks.")

# ── 5. STOCKOUT RISK ANALYSIS ───────────────────────────────────────────────────
print("[5] Running stockout risk analysis...")

hist_mean = df_sku["y"].mean()
hist_std  = df_sku["y"].std()

# Reorder Point = (Avg demand × Lead time) + Safety stock
reorder_point = hist_mean * LEAD_TIME_WEEKS + hist_std * SAFETY_STOCK_WEEKS

future_fc = forecast_out[forecast_out["date"] > df_sku["ds"].max()].copy()
future_fc["reorder_point"]   = round(reorder_point)
future_fc["demand_vs_rop"]   = future_fc["forecast_units"] - future_fc["reorder_point"]
future_fc["stockout_risk"]   = future_fc["upper_bound"].apply(
    lambda x: "HIGH" if x > reorder_point * 1.3
    else ("MEDIUM" if x > reorder_point else "LOW")
)

print(f"\n    Reorder Point (ROP): {round(reorder_point)} units/week")
print(f"    Safety Stock ({SAFETY_STOCK_WEEKS} weeks): {round(hist_std * SAFETY_STOCK_WEEKS)} units")
print(f"\n    {'Date':<14} {'Forecast':>10} {'ROP':>8} {'Risk':<10}")
print("    " + "-" * 46)
for _, row in future_fc.iterrows():
    print(f"    {str(row['date'].date()):<14} {row['forecast_units']:>10} {row['reorder_point']:>8} {row['stockout_risk']:<10}")

# ── 6. ALL-SKU SUMMARY ─────────────────────────────────────────────────────────
print("\n[6] Running all-SKU risk summary...")

all_skus    = df["sku"].unique()
all_regions = df["region"].unique()
summary_rows = []

for sku in all_skus:
    for region in all_regions:
        sub = df[(df["sku"] == sku) & (df["region"] == region)].groupby("date")["units_sold"].sum().reset_index()
        sub.columns = ["ds", "y"]
        if len(sub) < 10:
            continue
        m = sub["y"].mean()
        s = sub["y"].std()
        rop = m * LEAD_TIME_WEEKS + s * SAFETY_STOCK_WEEKS

        # Quick forecast: last 4 weeks average as proxy (fast, no Prophet loop)
        recent_avg = sub.tail(4)["y"].mean()
        risk = "HIGH" if recent_avg > rop * 1.2 else ("MEDIUM" if recent_avg > rop else "LOW")
        summary_rows.append({
            "sku": sku, "region": region,
            "avg_weekly_demand": round(m),
            "reorder_point": round(rop),
            "recent_4wk_avg": round(recent_avg),
            "stockout_risk": risk
        })

summary_df = pd.DataFrame(summary_rows).sort_values("stockout_risk")
print(summary_df.to_string(index=False))

# ── 7. SAVE OUTPUTS ────────────────────────────────────────────────────────────
forecast_out.to_csv("outputs/forecast_full.csv", index=False)
future_fc.to_csv("outputs/stockout_risk_next12weeks.csv", index=False)
summary_df.to_csv("outputs/all_sku_risk_summary.csv", index=False)
print("\n[7] Outputs saved to /outputs/")

# ── 8. PLOT ────────────────────────────────────────────────────────────────────
print("[8] Generating forecast chart...")

fig, axes = plt.subplots(2, 1, figsize=(13, 9))
fig.suptitle(f"FMCG Demand Forecast — {TARGET_SKU} | {TARGET_REGION} Region",
             fontsize=14, fontweight="bold", y=0.98)

# Plot 1: Forecast
ax1 = axes[0]
split_date = df_sku["ds"].max()

ax1.plot(df_sku["ds"], df_sku["y"], color="#2c5f8a", linewidth=1.2, label="Actual Sales")
fc_future = forecast_out[forecast_out["date"] > split_date]
fc_hist   = forecast_out[forecast_out["date"] <= split_date]

ax1.plot(fc_hist["date"], fc_hist["forecast_units"], color="#888", linewidth=0.8, linestyle="--", alpha=0.6)
ax1.plot(fc_future["date"], fc_future["forecast_units"], color="#e84545", linewidth=2, label="Forecast")
ax1.fill_between(fc_future["date"], fc_future["lower_bound"], fc_future["upper_bound"],
                 alpha=0.15, color="#e84545", label="90% Confidence Interval")
ax1.axvline(split_date, color="gray", linestyle=":", linewidth=1)
ax1.axhline(reorder_point, color="orange", linestyle="--", linewidth=1.2, label=f"Reorder Point ({round(reorder_point)})")
ax1.set_ylabel("Units Sold / Week")
ax1.legend(fontsize=8)
ax1.set_title("Weekly Demand Forecast (Prophet + Indian Festival Holidays)", fontsize=10)
ax1.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=4))
plt.setp(ax1.xaxis.get_majorticklabels(), rotation=30, ha="right")

# Plot 2: Stockout risk heatmap (bar chart)
ax2 = axes[1]
colors = {"HIGH": "#e84545", "MEDIUM": "#f0a500", "LOW": "#27ae60"}
bar_colors = [colors[r] for r in future_fc["stockout_risk"]]
bars = ax2.bar(future_fc["date"], future_fc["forecast_units"], color=bar_colors, width=5, alpha=0.85)
ax2.axhline(reorder_point, color="orange", linestyle="--", linewidth=1.5, label=f"Reorder Point ({round(reorder_point)})")
ax2.set_ylabel("Forecast Units")
ax2.set_title("12-Week Stockout Risk (Red=HIGH | Orange=MEDIUM | Green=LOW)", fontsize=10)
ax2.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
ax2.legend(fontsize=8)
plt.setp(ax2.xaxis.get_majorticklabels(), rotation=30, ha="right")

plt.tight_layout()
plt.savefig("outputs/demand_forecast_chart.png", dpi=150, bbox_inches="tight")
print("    Chart saved: outputs/demand_forecast_chart.png")

print("\n" + "=" * 60)
print("DONE. Upload /outputs/ folder to GitHub under pamarz.")
print("=" * 60)
